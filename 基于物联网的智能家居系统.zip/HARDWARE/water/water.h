#ifndef __WATER_H
#define	__WATER_H
#include "stm32f10x.h"
 

 
void WATER_CONFIG(void);
 
#endif /* __FIRE_H */


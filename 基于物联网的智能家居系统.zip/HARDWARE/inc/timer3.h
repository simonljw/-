

#ifndef _TIMER3_H
#define _TIMER3_H

void TIM3_ENABLE_30S(void);
void TIM3_ENABLE_2S(void);

#endif

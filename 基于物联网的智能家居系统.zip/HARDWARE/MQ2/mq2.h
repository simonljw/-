#ifndef __MQ2_H
#define __MQ2_H
#include "sys.h"


void MQ2_PPM_Calibration(float RS);
float MQ2_GetPPM(void);

#endif 


#include "fire.h"
#include "stm32f10x.h"
 
 
void FIRE_CONFIG(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;
 
		RCC_APB2PeriphClockCmd(GPIO_FIRE_CLK, ENABLE); 
 
		GPIO_InitStructure.GPIO_Pin = GPIO_FIRE_PIN;
	
		/*����GPIOģʽΪ��������*/
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  
 
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
 
		/*���ÿ⺯������ʼ��GPIO*/
		GPIO_Init(GPIO_FIRE_PORT, &GPIO_InitStructure);			 	
}





 

